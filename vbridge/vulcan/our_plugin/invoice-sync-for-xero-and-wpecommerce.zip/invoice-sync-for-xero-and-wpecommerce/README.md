=== Invoice-Sync-for-Xero-and-WPeCommerce ===
Contributors: arif.vbridge
Tags: xero, WPeCommerce, invoice
Requires at least: 3.0.1
Tested up to: 4.0.8
Stable tag: 4.0.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Xero Sync is an extension of WP eCommerce plugin. This plugin syncs Invoices for all purchases in the WP eCommerce plugin to Xero.
For syncing with Xero, this plugin needs a Xero private application to be registered in the user's Xero Account. The plugin will list all the invoices added using plugin
