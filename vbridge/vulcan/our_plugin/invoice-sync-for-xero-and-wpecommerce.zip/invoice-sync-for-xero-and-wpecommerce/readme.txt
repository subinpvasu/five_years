=== Invoice-Sync-for-Xero-and-WPeCommerce ===
Contributors: arif.vbridge
Tags: xero, WPeCommerce, invoice
Requires at least: 3.0.1
Tested up to: 4.0.8
Stable tag: 4.0.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Xero Sync is an extension of WP eCommerce plugin. This plugin syncs Invoices for all purchases in the WP eCommerce plugin to Xero.
For syncing with Xero, this plugin needs a Xero private application to be registered in the user's Xero Account. The plugin will list all the invoices added using plugin

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Xero Sync->Xero Auth to configure the plugin
