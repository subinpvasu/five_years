<html>
    <head>
        <title>Xero OAuth PHP</title>
    </head>
    <body>
        <h1>Howdy</h1>
        <ol>
            <li>A sample script for Private API applications <a href="private.php">private.php</a>
            </li>
            <li>A sample script for Public API applications <a href="public.php">public.php</a>
            </li>
              <li>A sample script for Partner API applications <a href="partner.php">partner.php</a>
            </li>
        </ol>

    </body>
</html>
