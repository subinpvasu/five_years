<?php
/* @var $this CustomersController */
/* @var $model Customers */
/* @var $form CActiveForm */
?>

<div class="form">

	<?php $form=$this->beginWidget('CActiveForm', array(
			'id'=>'customers-form',
			// Please note: When you enable ajax validation, make sure the corresponding
			// controller action is handling ajax validation correctly.
			// There is a call to performAjaxValidation() commented in generated controller code.
			// See class documentation of CActiveForm for details on this.
			'enableAjaxValidation'=>false,
	)); ?>

	<p class="note">
		Fields with <span class="required">*</span> are required.
	</p>

	<?php echo $form->errorSummary($model); ?>
	<?php //print_r($model);?>
	<div class="row">
		<?php echo $form->labelEx($model,'company'); ?>
		<?php echo $form->textField($model,'company',array('size'=>40,'maxlength'=>40)); ?>
		<?php echo $form->error($model,'company'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'name'); ?>
		<?php echo $form->textField($model,'name',array('size'=>40,'maxlength'=>40)); ?>
		<?php echo $form->error($model,'name'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'city'); ?>
		<?php echo $form->textField($model,'city',array('size'=>60,'maxlength'=>75)); ?>
		<?php echo $form->error($model,'city'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'location'); ?>
		<?php echo $form->textField($model,'location',array('size'=>50,'maxlength'=>50)); ?>
		<?php echo $form->error($model,'location'); ?>
	</div>
	<div class="row">
		<?php echo $form->labelEx($model,'status'); ?>
		<input type="radio" value="1" id="Customers_status"
			name="Customers[status]"
			<?php if($model->status == 1) echo 'checked="checked"';?>>Active <input
			type="radio" value="0" id="Customers_status" name="Customers[status]"
			<?php if($model->status == 0) echo 'checked="checked"';?>>Suspend
		<?php //echo $form->textField($model,'status'); ?>
		<?php echo $form->error($model,'status'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'device'); ?>
		<?php echo $form->textField($model,'device'); ?>
		<?php echo $form->error($model,'device'); ?>
	</div>
<?php /*
	<div class="row">
		<?php echo $form->labelEx($model,'to'); ?>
		<?php echo $form->textField($model,'to'); ?>
		<?php echo $form->error($model,'to'); ?>
	</div>
 */ ?>
	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Add' : 'Save'); ?>
	</div>

	<?php $this->endWidget(); ?>

</div>
<!-- form -->
<link
	rel="stylesheet" type="text/css"
	href="<?php echo Yii::app()->request->baseUrl; ?>/css/datepicker.css" />
<script
	type="text/javascript"
	src="<?php echo Yii::app()->request->baseUrl.'/js/datepick/jquery.js'; ?>"></script>
<script
	type="text/javascript"
	src="<?php echo Yii::app()->request->baseUrl.'/js/datepick/'; ?>datepicker.js"></script>
<script
	type="text/javascript"
	src="<?php echo Yii::app()->request->baseUrl.'/js/datepick/'; ?>eye.js"></script>
<script
	type="text/javascript"
	src="<?php echo Yii::app()->request->baseUrl.'/js/datepick/'; ?>layout.js?ver=1.0.2"></script>

<script>
	$('#Customers_from').DatePicker({
	format:'y-m-d',
	date: $('#Customers_from').val(),
	current: $('#Customers_from').val(),
	starts: 1,
	position: 'r',
	onBeforeShow: function(){
		new_date = $('#Customers_from').val();
		//alert(new_date);
		$('#Customers_from').DatePickerSetDate($('#Customers_from').val(), false);
	},
	onChange: function(formated, dates){
		$('#Customers_from').val(formated);
			$('#Customers_from').DatePickerHide();
	}
});
$('#Customers_to').DatePicker({
	format:'y-m-d',
	date: $('#Customers_to').val(),
	current: $('#Customers_to').val(),
	starts: 1,
	position: 'r',
	onBeforeShow: function(){
		$('#Customers_to').DatePickerSetDate($('#Customers_to').val(), false);
	},
	onChange: function(formated, dates){
		$('#Customers_to').val(formated);
			$('#Customers_to').DatePickerHide();
	}
});
</script>
