<?php
/* @var $this PlaylistsController */
/* @var $model Playlists */

$this->breadcrumbs=array(
	'Playlists'=>array('index'),
	$model->name,
);

?>
<div id="main">
	<div class="main-holder">
		<div class="container_12">
			<div class="grid_12 main-frame2">
				<strong class="sub-ttl" style="color: #DA6C0B;
			    display: block;
			    font: 22px 'BertholdAkzidenzGroteskBERegu',Arial,Helvetica,sans-serif;
			    z-index: auto; margin-left: 19%;">View Playlists - <?php echo $model->name; ?></strong>

				<?php 
				$style_list = array('none');
				$song_styles = array();
				$str_remove = array('{','}');
				foreach($styles as $style): 
					$style_list[$style->id] = $style->name;
				endforeach;
				
				$current_styles = explode(',',str_replace($str_remove,'',$model->style));
				foreach($current_styles as $current_style)
				{
					if(array_key_exists($current_style ,$style_list))
					$song_styles[$current_style] = $style_list[$current_style];
				}
				$style_tags = implode(',',$song_styles);
				?>
				
				<?php $this->widget('zii.widgets.CDetailView', array(
					'data'=>$model,
					'attributes'=>array(
						'id',
						'name',
						//'style',
						array
						(
								'name'=>'styles',
								'htmlOptions'=>array('style'=>'text-align: center'),
								'value'=> "$style_tags",
						),
					),
				)); ?>
				<div class="sub-menu">	
				<?php 
				$this->widget('zii.widgets.CMenu', array(
						'items'=>array(
								array('label'=>'Add New', 'url'=>array('create')),
								array('label'=>'Edit '.ucfirst($model->name), 'url'=>array('update&id='.$model->id)),
								array('label'=>'Manage', 'url'=>array('admin'),
								),									
						),
				));
				?>

			</div>
		</div>
	</div>
</div>
<style>
.sub-menu {
margin-top:0px;}
</style>