<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - 404';
$this->breadcrumbs=array(
		'About',
);
?>
<div id="main">
	<div class="main-holder">
		<div class="container_12">
			<div class="grid_12 main-frame2">
				<img src="<?php echo Yii::app()->request->baseUrl; ?>/images/kidmondo.jpg" style="margin: 0 12%;
    width: 700px;">
			</div>
			<div class="clear"></div>
		</div>
	</div>
</div>
