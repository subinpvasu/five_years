<?php
/* @var $this SongsController */
/* @var $model Songs */

$this->breadcrumbs=array(
	'Songs'=>array('index'),
	'Manage',
);

?>
<link href="/instore_php/assets/2a00851d/gridview/styles.css" type="text/css" rel="stylesheet">
<div id="main">
	<div class="main-holder">
		<div class="container_12">
			<div class="grid_12 main-frame2">
				<strong class="sub-ttl" style="color: #DA6C0B;
			    display: block;
			    font: 22px 'BertholdAkzidenzGroteskBERegu',Arial,Helvetica,sans-serif;
			    z-index: auto; margin-left: 19%;">Manage Songs</strong>
				<?php // $value = 'hii'?>
				<div class="grid-view" id="songs-grid">
					<div class="summary"><?php $this->widget('CLinkPager', array(
    'pages' => $pages,
)) ?></div>
					<table class="items">
					<thead>
					<tr>
					<th id="songs-grid_c0"><a href="/instore_php/index.php?r=songs/admin&amp;Songs_sort=name" class="sort-link">Name</a></th><th id="songs-grid_c1"><a href="/instore_php/index.php?r=songs/admin&amp;Songs_sort=style" class="sort-link">Style</a></th><th id="songs-grid_c2"><a href="/instore_php/index.php?r=songs/admin&amp;Songs_sort=path" class="sort-link">Path</a></th><th id="songs-grid_c3" class="button-column">&nbsp;</th></tr>
					</thead>
					<tbody>
					<?php $style_list = array('none');
					$song_styles = array();
					$str_remove = array('{','}');
					foreach($styles as $style): 
						$style_list[$style->id] = $style->name;
					 endforeach; 
					 foreach($models as $model)
					 {
						 $song_styles = array();
						 //$song_styles = $model->style;
						 $current_styles = explode(',',str_replace($str_remove,'',$model->style));
						 foreach($current_styles as $current_style)
						 {
						 	$song_styles[$current_style] = $style_list[$current_style];
						 }
						 //print_r($song_styles);
						 ?>
						<tr class="odd">
							<td><a href="/instore_php/songs/<?=$model->path?>" title="Delete" target="_blank"><?=$model->name?></a></td>
							<td><?=implode(',',$song_styles)?></td>
							<td><?=$model->path?></td>
							<td class="button-column">
								<a href="/instore_php/index.php?r=songs/view&amp;id=<?=$model->id?>" title="View" class="view">
									<img alt="View" src="/instore_php/assets/2a00851d/gridview/view.png">
								</a>
								<a  href="/instore_php/index.php?r=songs/update&amp;id=<?=$model->id?>" title="Update" class="update">
									<img alt="Update" src="/instore_php/assets/2a00851d/gridview/update.png">
								</a> 
								<a href="/instore_php/index.php?r=songs/delet&amp;id=<?=$model->id?>" title="Delete" class="delete">
									<img alt="Delete" src="/instore_php/assets/2a00851d/gridview/delete.png">
								</a>
							</td>
						</tr>						
					<?php } 
					 ?>
					</tbody>
					</table>
					<?php $this->widget('CLinkPager', array(
					    'pages' => $pages,
					)) ?>
				</div>
				<div class="sub-menu">	
				<?php 
				$this->widget('zii.widgets.CMenu', array(
						'items'=>array(
								array('label'=>'Add New', 'url'=>array('create')),
						),
				));
				?>
				
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
if($popup != '')
{?>
<script type="text/javascript">
</script>
<?php	
}
?>
<script type="text/javascript">
		$(document).ready(function() {
			$.fancybox.close(true);
				$('.fancybox').fancybox();
				$('.delete').on("click", null, function(){
					return confirm("Are you sure you want to delete this song");
				});
				
		});
	</script>
	<style type="text/css">
		.fancybox-custom .fancybox-skin {
			box-shadow: 0 0 50px #222;
		}
		.button-column ul {
		float: left;
		}
		.button-column li {
		float: left;
	    margin-left: 14px;
	    margin-right: -34px;
	    text-decoration: none;
		}
		
	</style>