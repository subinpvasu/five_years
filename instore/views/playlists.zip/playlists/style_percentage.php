<?php
/* @var $this PlaylistsController */
/* @var $model Playlists */

$this->breadcrumbs=array(
	'Playlists'=>array('index'),
	$model->name,
);

?>
<div id="main">
	<div class="main-holder">
		<div class="container_12">
			<div class="grid_12 main-frame2">
				<strong class="sub-ttl" style="color: #DA6C0B;
			    display: block;
			    font: 22px 'BertholdAkzidenzGroteskBERegu',Arial,Helvetica,sans-serif;
			    z-index: auto; margin-left: 19%;">Change style percentage - <?php echo $model->name; ?></strong>
				<div class="form">
					<?php if($errors != '')
					{
						echo '<div class="errorSummary"><p>Please fix the following input errors:</p>
								<ul>
									<li>'.$errors.'</li>
								</ul>
							</div>';
					}
					?>
					<form method="post" action="/instore_php/index.php?r=playlists/add_style_persentage&id=<?php echo $model->id; ?>" id="playlists">
						<?php foreach($styles_percentages as $key => $styles_percentage)
						{
						?>						
							<div class="row">
								<label class="required" for="Playlists_name"><?= $styles[$styles_percentage['style']]?> <span class="required">*</span></label>									<input type="text" id="Playlists_name" name="Playlists[style][<?= $key?>]" maxlength="100" size="60" value="<?=$styles_percentage['percentage']?>">			
							</div>
						<?php }?>
						<div class="row buttons"> <input class="style_btn" type="submit" value="Save" name="yt0">	</div>					
					</form>
				</div>
				<div class="sub-menu">
				<?php 
				$this->widget('zii.widgets.CMenu', array(
						'items'=>array(
								array('label'=>'Add New', 'url'=>array('create')),
								array('label'=>'View '.ucfirst($model->name), 'url'=>array('view&id='.$model->id)),
								array('label'=>'Edit '.ucfirst($model->name), 'url'=>array('update&id='.$model->id)),
								array('label'=>'Manage', 'url'=>array('admin'),
								),									
						),
				));
				?>
				</div>
			</div>
		</div>
	</div>
</div>
<style>
input {
    border: 1px solid #33CCCC;
    padding: 10px;
    width: 45px;
}
</style>
