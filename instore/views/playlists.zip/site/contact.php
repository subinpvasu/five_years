<style>
#footer {
	margin-top: 0px;
}
</style>
<div id="main">
	<div class="main-holder">
		<div class="container_12">
			<div class="grid_12 main-frame2">
				<div class="page-ttl">
					<h1>Contact</h1>
				</div>
				<div class="clear"></div>
				<div style="padding: 10px" class="txt">
					<h5>INTERNATIONAL CUSTOMERS AND NEW AGENTS</h5>
					<br> My Instore Radio International<br> Tel.: 00 45 70 229 221<br>
					E-mail: <a href="mailto:sales@myinstoreradio.com">sales@myinstoreradio.com</a><br>
					Web: <a target="_blank" href="index.html">http://www.myinstoreradio.com</a>
					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="index.html"><img
										src="images/Agent_MIR.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
								</td>
							</tr>

						</tbody>
					</table>
					<h5>AUSTRALIA</h5>
					<br>

					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank"
									href="http://www.creativecorporatemedia.com.au/"><img
										src="images/Agent_CCM.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									Creative Corporate Media<br> Tel.: 1300 36 30 29<br> E-mail: <a
									href="mailto:sales@creativecorporatemedia.com.au">sales@creativecorporatemedia.com.au</a><br>
									Web: <a target="_blank"
									href="http://www.creativecorporatemedia.com.au/">http://www.creativecorporatemedia.com.au</a>
								</td>
							</tr>
						</tbody>
					</table>
					<h5>COLUMBIA</h5>
					<br>
					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="http://www.inspiringsenses.com/"><img
										src="images/Agent_InspiringSenses.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									Inspiring Senses<br> Tel.: +57(1) 750 0820<br> E-mail: <a
									href="mailto:aa@inspiringsenses.com">aa@inspiringsenses.com</a><br>
									Web: <a target="_blank" href="http://www.inspiringsenses.com/">http://www.inspiringsenses.com</a>
								</td>
							</tr>
						</tbody>
					</table>

					<h5>COSTA RICA</h5>
					<br>
					<table cellspacing="0" cellpadding="0" border="0">

						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="http://www.insidemusiccr.com/"><img
										src="images/Agent_InsideMusic.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									Inside Music<br> Tel.: +506 40 00 38 71<br> E-mail: <a
									href="mailto:info@insidemusiccr.com">info@insidemusiccr.com</a><br>
									Web: <a target="_blank" href="http://www.insidemusiccr.com/">http://www.insidemusiccr.com</a>
								</td>
							</tr>
						</tbody>
					</table>
					<h5>DENMARK</h5>
					<br>
					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="http://www.avdesign.dk/"><img
										src="images/AVdesign.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									AVdesign<br> Tel.: 70 229 229<br> E-mail: <a
									href="mailto:mail@avdesign.dk">mail@avdesign.dk</a><br> Web: <a
									target="_blank" href="http://www.avdesign.dk/">http://www.avdesign.dk</a>
								</td>

								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="index.html"><img
										src="images/Agent_MIR.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									My Instore Radio<br> Tel.: 70 229 221<br> E-mail: <a
									href="mailto:sales@myinstoreradio.com">sales@myinstoreradio.com</a><br>
									Web: <a target="_blank" href="index.html">http://www.myinstoreradio.com</a>
								</td>

							</tr>
						</tbody>
					</table>
					<h5>FRANCE</h5>
					<br>
					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="http://www.wimmproductions.com/"><img
										src="images/Agent_WIMMproductions.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									WIMM PRODUCTIONS<br> Tel.: 09 52 76 98 15<br> E-mail: <a
									href="mailto:contact@wimmproductions.com">contact@wimmproductions.com</a><br>
									Web: <a target="_blank" href="http://www.wimmproductions.com/">http://www.wimmproductions.com</a>
								</td>

								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="index.html"><img
										src="images/Agent_MIR.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									POSISION OPEN FOR AGENT<br> Tel.: +45 70 229 221<br> E-mail: <a
									href="mailto:sales@myinstoreradio.com">sales@myinstoreradio.com</a><br>
									Web: <a target="_blank" href="index.html">http://www.myinstoreradio.com</a>
								</td>

							</tr>
						</tbody>
					</table>
					<h5>ITALY</h5>
					<br>
					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="http://www.myinstoreradio.it/"><img
										src="images/Agent_BVMEDIA.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									BVMEDIA SRL<br> Tel.: 3486726030<br> E-mail: <a
									href="mailto:info@myinstoreradio.it">info@myinstoreradio.it</a><br>
									Web: <a target="_blank" href="http://www.myinstoreradio.it/">http://www.myinstoreradio.it</a>
								</td>
							</tr>
						</tbody>
					</table>
					<h5>MALAWI</h5>
					<br>
					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="http://www.audiovision360.com/"><img
										src="images/AudioVision360.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									Audio Vision 360<br> Tel.: 00265 995 700 205<br> E-mail: <a
									href="mailto:info@audiovision360.com ">info@audiovision360.com
								</a><br> Web: <a target="_blank"
									href="http://www.audiovision360.com/">http://www.audiovision360.com</a>
								</td>
							</tr>
						</tbody>
					</table>
					<h5>NORWAY</h5>
					<br>
					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="index.html"><img
										src="images/Agent_MIR.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									Bo Bundgaard<br> Tel.: +45 30 83 69 00<br> E-mail: <a
									href="mailto:bbu@myinstoreradio.com">bbu@myinstoreradio.com</a><br>
									Web: <a target="_blank" href="index.html">http://www.myinstoreradio.com</a>
								</td>
							</tr>
						</tbody>
					</table>
					<h5>SOUTH AFRICA</h5>
					<br>
					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="index.html"><img
										src="images/Agent_InstoreMusic_And_Advertising.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									Instore Music &amp; Advertising<br> Tel.: +27 83 679 8222<br>
									E-mail: <a href="mailto:sales@myinstoreradio.com">sales@myinstoreradio.com</a><br>
									Web: <a target="_blank" href="index.html">http://www.myinstoreradio.com</a>
								</td>
							</tr>
						</tbody>
					</table>
					<h5>SWEDEN</h5>
					<br>
					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="index.html"><img
										src="images/Agent_MIR.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									Bo Bundgaard<br> Tel.: +45 30 83 69 00<br> E-mail: <a
									href="mailto:bbu@myinstoreradio.com">bbu@myinstoreradio.com</a><br>
									Web: <a target="_blank" href="index.html">http://www.myinstoreradio.com</a>
								</td>

								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="index.html"><img
										src="images/Agent_MIR.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									POSISION OPEN FOR AGENT<br> Tel.: +45 70 229 221<br> E-mail: <a
									href="mailto:sales@myinstoreradio.com">sales@myinstoreradio.com</a><br>
									Web: <a target="_blank" href="index.html">http://www.myinstoreradio.com</a>
								</td>

							</tr>
						</tbody>
					</table>
					<h5>USA</h5>
					<br>
					<table cellspacing="0" cellpadding="0" border="0">


						<tbody>
							<tr>
								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="index.html"><img
										src="images/Agent_MIR.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									POSISION OPEN FOR AGENT<br> Tel.: +45 70 229 221<br> E-mail: <a
									href="mailto:sales@myinstoreradio.com">sales@myinstoreradio.com</a><br>
									Web: <a target="_blank" href="index.html">http://www.myinstoreradio.com</a>
								</td>

								<td
									style="vertical-align: top; padding-top: 10px; text-align: left;">
									<a target="_blank" href="index.html"><img
										src="images/Agent_InsideMusic.png"> </a>
								</td>

								<td
									style="width: 400px; vertical-align: top; padding-left: 40px; padding-top: 10px; text-align: left;">
									Inside Music<br> Tel.: 888 474 9990<br> E-mail: <a
									href="mailto:sales@myinstoreradio.com">sales@myinstoreradio.com</a><br>
									Web: <a target="_blank" href="index.html">http://www.myinstoreradio.com</a>
								</td>

							</tr>

						</tbody>
					</table>
				</div>
			</div>
			<div class="clear"></div>
		</div>
	</div>
</div>
