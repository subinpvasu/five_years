<?php

class CustomersController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column3';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
				'accessControl', // perform access control for CRUD operations
				'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
				array('allow',  // allow all users to perform 'index' and 'view' actions
						'actions'=>array('index','view', 'change_ip', 'return_playlist'),
						'users'=>array('*'),
				),
				array('allow', // allow authenticated user to perform 'create' and 'update' actions
						'actions'=>array('create','update','chart'),
						'users'=>array('@'),
				),
				array('allow', // allow admin user to perform 'admin' and 'delete' actions
						'actions'=>array('admin','delet','suspend','activate'),
						'users'=>array('admin'),
				),
				array('deny',  // deny all users
						'users'=>array('*'),
				),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id='')
	{
		if($id == '')
		{
			$this->redirect(array('site/notfound'));
		}
		$this->render('view',array(
				'model'=>$this->loadModel($id),
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new Customers;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Customers']))
		{
			$model->attributes=$_POST['Customers'];
			if($model->save())
				$this->redirect(array('chart','id'=>$model->id));
		}

		$this->render('create',array(
				'model'=>$model,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id = '')
	{
		if($id == '')
		{
			$this->redirect(array('site/notfound'));
		}
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Customers']))
		{
			$model->attributes=$_POST['Customers'];
			if($model->save())
				$this->redirect(array('view','id'=>$model->id));
		}

		$this->render('update',array(
				'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelet($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}
	/* Function to suspend a purticular user */
	public function actionSuspend($id)
	{
		$model=$this->loadModel($id);
		if(isset($_GET['id']))
		{
			$model->updateByPk($model->id,array('status' => 0));
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
		}
		//if(!isset($_GET['ajax']))
			
	}
	public function actionActivate($id)
	{
		$model =$this->loadModel($id);
		if(isset($_GET['id']))
		{
			//$model->status=1;
			$model->updateByPk($model->id,array('status' => 1));
			//$model->save();
				$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
		}
		//if(!isset($_GET['ajax']))
			
	}
	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$this->redirect(array('admin'));
		$dataProvider=new CActiveDataProvider('Customers');
		$this->render('index',array(
				'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new Customers('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Customers']))
			$model->attributes=$_GET['Customers'];

		$this->render('admin',array(
				'model'=>$model,
		));
	}
	public function actionChart($id='')
	{
		$error = array();
		$all_list = array();
		$error_tittle = '';
		$success_msg = '';
		$defalt_playlist_arry = array();
		$play_list_id_name_array = array();
		$days = array('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
		$str_remove = array('{','}');
		$uid = $id;
		if($uid == '') $uid = 0;
		$allplaylists = Playlists::model()->findAll();
		foreach($allplaylists as $single_playlist) 
		{
			array_push($defalt_playlist_arry,$single_playlist->id);
			$play_list_id_name_array[$single_playlist->id] = $single_playlist->id.' - '.$single_playlist->name;
		}
		if($id != '') $model =$this->loadModel($id);
		else $model = new Customers;
		if(isset($_POST['list']))
		{
			$shedule = array();
			$ad_no = $_POST['list']['ad_no'];
			$ad_gap = $_POST['list']['ad_gap'];
			$jingle_gap = $_POST['list']['jingle_gap'];
			if($ad_no == '')
			{
				$null_field_error = 'Number of Ads required<br />';
				//$null_field_error = 'Number of Ads must be number';
				array_push($error,$null_field_error);
			}
			elseif(!is_numeric($ad_no))
			{
				//$error_tittle .= '<br />';
				$null_field_error = 'Number of Ads must be number';
				array_push($error,$null_field_error);
			}
			if($ad_gap =='')
			{
				$null_field_error = 'Number of Tracks between Ads required<br />';
				//$null_field_error = 'Number of Ads must be number';
				array_push($error,$null_field_error);
			}
			elseif(!is_numeric($ad_gap))
			{
				$null_field_error = 'Number of Tracks between ads must be number<br />';
				array_push($error,$null_field_error);
			}
			if($jingle_gap =='')
			{
				$null_field_error = 'Number of Tracks between Jingles required<br />';
				array_push($error,$null_field_error);
			}
			elseif(!is_numeric($jingle_gap))
			{
				$null_field_error = 'Number of Tracks between Jingles must be number<br />';
				array_push($error,$null_field_error);
			}
			$all_list = $_POST['list']['chart'];
			foreach($all_list as $key=>$single_list)
			{
				$key_array = explode('_',$key);
				$chart_day = $key_array[0];
				$chart_time = $key_array[1];
				//echo 'Day = '.$days[$chart_day].', Time = '.$chart_time.', Playlist = '.$single_list.'<br />';
				if($single_list == '')
				{ 	
					$null_field_error = $chart_time.' in '.$days[$chart_day].'  cannot be blank.';
					array_push($error,$null_field_error);
				}
				if(!in_array($single_list,$defalt_playlist_arry) && $single_list != '')
				{
					$null_field_error = 'Playlist '.$single_list.' on '.$chart_time.' '.$days[$chart_day].'  is not exist.';
					array_push($error,$null_field_error);
				}
				$curnt_vals[$chart_day][$chart_time] = $single_list;
			}
			if(empty($error))
			{
				if($id != '')
				{
					$model->updateByPk($id,array('ad_no' => $ad_no, 'ad_gap' => $ad_gap,'jingle_gap' => $jingle_gap));
				}
				
				foreach($curnt_vals as $key=>$curnt_val)
				{
						$play_list = '{'.implode(',',$curnt_val).'}';
						$condition = '`uid` = '.$uid.' AND `day` = '.$key;
						$list = Charts::model()->findAll(array('condition'=> $condition));
						if(empty($list))
						{						
							Charts::model()->setIsNewRecord(true);
							Charts::model()->id = null;
							Charts::model()->uid = $uid;
							Charts::model()->day = $key;
							Charts::model()->playlists = $play_list;
							Charts::model()->save();
							//echo 'Nothing';
						}
						else 
						{
							Charts::model()->updateByPk($list[0]->id,array('playlists' => $play_list));
						}						
				}
				$success_msg = 'Schedule updated successfully';
				//$this->refresh();
			}
			else $error_tittle = 'Plese fix following error<br />';
		}
		$condition = '`uid` = '.$uid;
		$get_chart_lists = Charts::model()->findAll(array('condition'=> $condition));
		if (empty($get_chart_lists))
		{
			$condition = '`uid` = 0';
			$get_chart_lists = Charts::model()->findAll(array('condition'=> $condition));
		}
		if(!empty($get_chart_lists))
		{
			foreach($get_chart_lists as $get_chart_list)
			{
				//print_r($get_chart_list);
				$daychart_array = explode(',',str_replace($str_remove,'',$get_chart_list->playlists));
				foreach ($daychart_array as $key=>$timeslot)
				{
					$all_list[$get_chart_list->day.'_'.$key] = $timeslot;
				}
			}
		}
		$this->render('chart',array(
				'model'=>$model,
				'errors' => $error,
				'error_titte' => $error_tittle,
				'chart' => $all_list,
				'defalt_playlist_arry' => $defalt_playlist_arry,
				'success_msg' => $success_msg,
				'play_list_id_name_array' =>$play_list_id_name_array,
		));
	}
	public function actionChange_ip()
	{
		if(isset($_POST['ip']) && isset($_POST['uid']))
		{
			$model = new Customers;
			$condition = '`uid` = '.$_POST['uid'];
			$get_user = $model->findAll(array('condition'=> $condition));
			foreach($get_user as $user)
			{
				if($_POST['ip'] == $user->ip)
				{
					if($this->updateByPk($user->id,array('ip' => $_POST['ip'])))
					{
						echo 'Updated';
					}
				}
				else echo 'Already exist';
			
			}
			exit;
		}
	}
	public function actionReturn_playlist($id= '')
	{
		if($id != '')
		{
			$customer_model =$this->loadModel($id);
			print_r($customer_model);
			$current_playlist_songs = array();
			$str_remove = array('{','}');
			$songs_ist = array();
			$all_songs = Songs::model()->findAll();
			foreach($all_songs as $songs)
			{
				$song_styles = explode(',',str_replace($str_remove,'',$songs->style));
				if(!empty($song_styles))
				{
					foreach($song_styles as $song_style)
					{
						if(!array_key_exists($song_style,$songs_ist)) $songs_ist[$song_style] = array();
						array_push($songs_ist[$song_style],array('id'=>$songs->id,'name' => $songs->name, 'path' => $songs->path));
					}
				}
			}
			$str_remove = array('{','}');
			$condition = '`uid` = '.$id;
			$get_last_playlist = Lastplayed::model()->findAll(array('condition'=> $condition));
			if(!empty($get_last_playlist))
			{
				$last_plyed_songs = explode(',',str_replace($str_remove,'',$get_last_playlist[0]->songs));
			}
			else {
				$last_plyed_songs = array();
				echo 'No previous playlist';
			}
			//echo '<pre>';
			//print_r($songs_ist);
			//exit;
			$days = array('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
			$today_index = array_search(date('D'), $days);
			$condition = '`uid` = '.$id.' AND `day` = '.$today_index;
			$get_chart_lists = Charts::model()->findAll(array('condition'=> $condition));
			
			if (empty($get_chart_lists))
			{
				$condition = '`uid` = 0 AND `day` = '.$today_index;
				$get_chart_lists = Charts::model()->findAll(array('condition'=> $condition));
			}
			$playlists = explode(',',str_replace($str_remove,'',$get_chart_lists[0]->playlists));
			echo '<pre>';
			
			if(!empty($playlists))
			{
				$user_day_styles = array();
				foreach($playlists as $key3=>$playlist)
				{
					$condition = '`id` = '.$playlist;
					$get_playlist_details = Playlists::model()->findAll(array('condition'=> $condition));
					$tags = explode(',',str_replace($str_remove,'',$get_playlist_details[0]->style));
					foreach($tags as $key2=>$tag)
					{
						if(array_key_exists($tag,$songs_ist)) 
						{
							foreach($songs_ist[$tag] as $key=>$songlist)
							{
								
								$f = Yii::getPathOfAlias('webroot').'/songs/'.$songlist['path'];
								
								
								//print_r($tag);
								//$f = 'somefile.mp3';
								$m = new mp3file($f);
								$a = $m->get_metadata();
								if(!empty($a) && array_key_exists('Length mm:ss',$a))
									$songs_ist[$tag][$key]['length'] = '00:'.$a['Length mm:ss'];
								else $songs_ist[$tag][$key]['length'] = '00:2:00';
							}
							$tags[$tag] = $songs_ist[$tag];
							//echo '<pre>';
							//print_r($songs_ist[$tag]);
							//echo $songs_ist[$tag]['path'].'<br />';
						}
						else $tags[$tag] = 'no tag exist';
						//unset($tags[$tag]);
					}
					unset($tags[0]);
					$user_day_styles['time_'.$key3] = $tags;
				}
				
			}
			else echo 'Invalid request';
			foreach ($user_day_styles as $key1=>$user_day_style)
			{
				foreach ($user_day_style as $key=>$user_day_time)
				{ 
					if(is_array($user_day_time)) shuffle($user_day_time);
					$user_day_styles[$key1][$key] = $user_day_time;
				}
				
			}
			foreach($user_day_styles as $keys=>$user_day_style)
			{
				$user_day_song_list = array();
				$total_time = strtotime("00:00:00");
				$maxtiome = strtotime("00:06:00");
				echo $keys.'<br />';
				foreach($user_day_style as $user_day_tags)
				{
					if(is_array($user_day_tags))
					{
						foreach($user_day_tags as $user_day_songs)
						
						{
							
							
							if(!in_array($user_day_songs['id'],$current_playlist_songs) && !in_array($user_day_songs['id'],$last_plyed_songs) && $total_time <= $maxtiome)
							{
								$secs = strtotime($user_day_songs['length'])-strtotime("00:00:00");
								$total_time = $total_time+$secs;
								array_push($current_playlist_songs,$user_day_songs['id']);
								$user_day_song_list[$key] = $user_day_songs;
								//print_r($user_day_songs);
							}
							elseif(!in_array($user_day_songs['id'],$last_plyed_songs) && $total_time <= $maxtiome)
							{
								$secs = strtotime($user_day_songs['length'])-strtotime("00:00:00");
								$total_time = $total_time+$secs;
								array_push($current_playlist_songs,$user_day_songs['id']);
								$user_day_song_list[$key] = $user_day_songs;
							}
						}
						
					}
				}
			}
			
			
			print_r($user_day_song_list);
			
		}
		else echo 'Invalid request';
		exit;
	}
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Customers the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Customers::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Customers $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='customers-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
