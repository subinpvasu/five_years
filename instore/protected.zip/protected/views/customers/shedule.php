<?php
/* @var $this SongsController */
/* @var $model Songs */
?>
<div id="main">
	<div class="main-holder">
		<div class="container_12">
			<div class="grid_12 main-frame2">
				<div id="login_overlay" style="display: block;">
					<div id="form_holder">
						<div class="page-ttl">
							<strong class="sub-ttl">Creating schedules</strong>
							<img src="<?php echo Yii::app()->request->baseUrl; ?>/images/ajax-loader.gif">
							
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</div>
<script>
$(document).ready(function(){
	alert('Success');
	$('#login_overlay').hide();	
}
</script>