<style>
#footer {
	margin-top: 0px;
}
</style>
<div id="main">
	<div class="main-holder">
		<div class="container_12">
			<div class="grid_12 main-frame2">
				<div class="page-ttl">
					<h1>Contact</h1>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</div>
