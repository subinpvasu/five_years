<?php /* @var $this Controller */ ?>

<?php echo $content; ?>
