<?php

class SongsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	//public $layout='//layouts/column3';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
		$this->layout = 'tag_popup';
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','get_style'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','selected_action','change_multy_style'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delet'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$styles = Style::model()->findAll();
		$this->render('view',array(
			'model'=>$this->loadModel($id),
				'styles' => $styles,
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
public function actionCreate()
	{
		$model=new Songs;
		$styles = Style::model()->findAll();
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
		if(isset($_POST) && !empty($_POST['Songs']))
        {
        	
			if(!empty($_POST['styles'])) $style = '{'.implode(',',$_POST['styles']).'}';
			else $style = '{0}';
        	$file_post = &$_FILES['song'];
        	$file_arys = array();
		    $file_count = count($file_post['name']);
		    $file_keys = array_keys($file_post);
		
		    for ($i=0; $i<$file_count; $i++) {
		        foreach ($file_keys as $key) {
		            $file_arys[$i][$key] = $file_post[$key][$i];
		        }
		    }
			$inserted_id = array();
			$log = 'Songs uploaded';
		    foreach($file_arys as $file_ary)
		    {
	        	$file_name = $file_ary['name'];
	        	$path = Yii::getPathOfAlias('webroot')."/songs/on".date('y-m');
	        	if (!file_exists($path)) {
	        		mkdir(Yii::getPathOfAlias('webroot').'/songs/on'.date('y-m'), 0777);
	        	}
	        	$extention_array = explode('.',$file_name);
	        	$extention = end($extention_array);
	        	$name = time().rand(1000,9999);// optional
	        	$name = md5($name).'.'.$extention; //optional
	        	if(move_uploaded_file($file_ary["tmp_name"],$path .'/'. $name))
				{
					 $log  .= 'Song name:  '.$file_name."\r\n".
					//echo 'uploaded';
					$model->name = $file_name;
					$model->style = $style;
					$model->path = 'on'.date('y-m').'/'. $name;
					//print_r($model);
					if($model->save())
					{
						echo 'saved';
					}
					$model=new Songs;
				}
				//echo 'uploaded';
		    }
		    $log_creation = New Createlog;
		    $log  .= "Time : ".' - '.date("F j, Y, H:i:s ").PHP_EOL."\r\n".
		    		"Action : Cronjob updated schedule".PHP_EOL."\r\n".
		    		
		    		"-------------------------".PHP_EOL."\r\n";
		    $log_creation->create_log_msg($log);
			$this->redirect(array('admin'));
		}
		
        $this->render('create', array('model'=>$model,'styles'=>$styles));
		
	}
	
	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{		
		///$this->layout = 'tag_popup';
		$model=$this->loadModel($id);
		$styles = Style::model()->findAll();
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Songs']))
		{
			if(!empty($_POST['Songs']['styles'])) $style = '{'.implode(',',$_POST['Songs']['styles']).'}';
			else $style = '{0}';
			//echo $style;
			$model->updateByPk($model->id,array('style'=>$style));
				$this->redirect(array('admin','popup'=>'exit'));
		}

		$this->render('update',array(
			'model'=>$model,
			'styles' => $styles,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelet($id)
	{
		$model=$this->loadModel($id);
		$path = $path = Yii::getPathOfAlias('webroot')."/songs/".$model->path;
		if(unlink($path)) $model->delete();
		//exit;
		
		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Songs');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}
public function actionGet_style($popup = '')
	{
		$style_name = '';
		if(isset($_GET["q"])) $style_name = $_GET["q"];
		$criteria=new CDbCriteria();
		$criteria->compare('name',$style_name,true,'AND');
		$styles = Style::model()->findAll($criteria);
		$style_array = array();
		$i=0;
		foreach($styles as $style)
		{
			$i++;
			$style_array[] = array('name'=>$style->name,'id' => $style->id);
		}
		$json_response = json_encode($style_array);

		# Optionally: Wrap the response in a callback function for JSONP cross-domain support
		if(isset($_GET["callback"])) {
			$json_response = $_GET["callback"] . "(" . $json_response . ")";
		}

		# Return the response
		echo $json_response;
		exit;
	}
	/**
	 * Manages all models.
	 */
	 public function actionChange_multy_style($song_list = '')
	{
		if($song_list != '')
		{
			$styles = Style::model()->findAll();
			$criteria=new CDbCriteria();
			$model=new Songs();
			$select_songs = explode('_',$song_list);
			$criteria->addInCondition('id',$select_songs,true,'OR');
			$songlists = $model->findAll($criteria);
			if(isset($_POST['Songs']))
			{
				if(!empty($_POST['Songs']['styles'])) $style = '{'.implode(',',$_POST['Songs']['styles']).'}';
				else $style = '{0}';
				//echo $style;
				foreach($songlists as $songlists)
				{
					$model->updateByPk($songlists->id,array('style'=>$style));					
				}
				$this->redirect(array('admin'));
			}
			//print_r($songlists);
			//exit;
			
		}
		else $this->redirect(array('admin'));
		$this->render('update_style',array(
			'model'=>$model,
			'styles' => $styles,
			'songlists'=>$songlists
		));
	}
	 public function actionSelected_action()
	{
		$return_url = $_POST['redirect_url'];
		echo $return_url.'<br />';
		if (strpos($return_url,'&check_sel=all')) {
			$str2 = explode("&", $return_url);
			array_pop($str2);
			$return_url = implode("&", $str2);
			}
		if(isset($_POST['Songs']) && !empty($_POST['Songs']['song_id']))
		{
			$song_list_url = implode('_',$_POST['Songs']['song_id']);			
			$criteria=new CDbCriteria();
			$model=new Songs();
			$criteria->addInCondition('id',$_POST['Songs']['song_id'],true,'OR');
			$songlists = $model->findAll($criteria);
			
			if(isset($_POST['Songs']['action']) && $_POST['Songs']['action'] == 'Delete')
			{
				foreach($songlists as $songlist)
				{
					$song_model=$this->loadModel($songlist->id);
					$path = $path = Yii::getPathOfAlias('webroot')."/songs/".$song_model->path;
					if(unlink($path)) $song_model->delete();
					echo 'deleted'.$path.'<br />';
					$this->redirect($return_url);
				}
				
			}
			if(isset($_POST['Songs']['action']) && $_POST['Songs']['action'] == 'Change style')
			{
				$this->redirect(array('change_multy_style','song_list'=>$song_list_url));
			}
		}
		else 
		{
			 Yii::app()->user->setFlash('error','Please select some songs');
			$this->redirect($return_url);
		}
		
	}
	public function actionAdmin($popup = '')
	{
		$styles = Style::model()->findAll();
		$style_array = array();
		$search_name = '';
		$search_style = '';
		foreach($styles as $style)
		{
			$style_array[$style->id] = $style->name;
		}
		$criteria=new CDbCriteria();
		$model=new Songs();
		$curnt_page = 1;
		$condition = '';
		$criteria->order =  'id DESC';
		if(isset($_GET['Songs']))
		{
			
			if(isset($_GET['Songs']['style']) && $_GET['Songs']['style'] != '') 
			{
				$search_styles = explode (',',$_GET['Songs']['style']);
				//$key_of_style = array_search($_GET['Songs']['style'], $style_array);
				if(is_array($search_styles) && !empty($search_styles))
				{
					foreach($search_styles as $search_style)
					{
						//echo 
						$criteria->compare('style','{'.$search_style,true,'OR');
						$criteria->compare('style',','.$search_style.',',true,'OR');
						$criteria->compare('style',$search_style.'}',true,'OR');
					}
				}
				else 
				{
					$criteria->compare('style','{'.$search_styles,true,'OR');
					$criteria->compare('style',','.$search_styles.',',true,'OR');
					$criteria->compare('style',$search_styles.'}',true,'OR');

				}
			}
			if(isset($_GET['Songs']['name']) && $_GET['Songs']['name'] != '') 
			{
				$search_name = $_GET['Songs']['name'];
				$criteria->compare('name',$_GET['Songs']['name'],true,'AND');
			}
		}
		
		if(isset($_GET['page'])) $curnt_page = $_GET['page'];
		if($curnt_page != 1) $curnt_page = 5*($curnt_page-1) + 1;
		$count=$model->count($criteria);
		$pages=new CPagination($count);
		
		// results per page
		$pages->pageSize=5;
		$pages->applyLimit($criteria);
		$models=$model->findAll($criteria);
		$select_all = '';
		if(isset($_GET['check_sel'] ) && $_GET['check_sel'] = 'all')
		{
			$select_all = 'checked="checked"';
		}
		$this->render('admin', array(
				'models' => $models,
				'pages' => $pages,
				'styles' => $styles,
				'popup' => $popup,
				'search_style' => $search_style,
				'search_name' => $search_name,
				'curnt_page' => $curnt_page,
				'total_count' => $count,
				'song_selection' => $select_all
		));
	}
	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Songs the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Songs::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Songs $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='songs-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
