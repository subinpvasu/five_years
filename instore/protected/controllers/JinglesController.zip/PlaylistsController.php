<?php
class PlaylistsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column3';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			//'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete','add_style_persentage'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$styles = Style::model()->findAll();
		$this->render('view',array(
			'model'=>$this->loadModel($id),
			'styles' => $styles,
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new Playlists;
		$percentage = new Stylepercentage;
		$style = '{0}';
		$styles = Style::model()->findAll();
		$stle_lst = '';
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Playlists']))
		{
			
			if(!empty($_POST['Playlists']['styles'])) 
			{
				$stle_lst = $_POST['Playlists']['styles'];
				$style = '{'.implode(',',$_POST['Playlists']['styles']).'}';
				//else $style = '';
				$_POST['Playlists']['styles'] = $style;
			}
			$model->attributes=$_POST['Playlists'];
			$model->style = $style;
			if($model->save())
			{
				
				if(!empty($stle_lst))
				{ 
					$length = count($stle_lst);
					$defalt_percentage = floatval(100/3);
					$defalt_percentage = round($defalt_percentage,2);
					//echo round($defalt_percentage,2);
					//exit;
					//$stle_lst = $_POST['Playlists']['styles'];
					foreach( $stle_lst as $single_style)
					{
						$percentage->setIsNewRecord(true);
                        $percentage->id = null;
						$percentage ->playlist = $model->id;
						$percentage ->percentage = $defalt_percentage;
						$percentage ->style = $single_style;
						//print_r($percentage);
						$percentage->save();
						//else exit;
												
					}
					$this->redirect(array('add_style_persentage','id'=>$model->id));
					//exit;
				}
				//exit;
				$this->redirect(array('view','id'=>$model->id));
			}
		}

		$this->render('create',array(
			'model'=>$model,
			'styles' => $styles,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		$stle_lst = '';
		$style = '{0}';
		$percentage = new Stylepercentage();
		$model=$this->loadModel($id);
		$styles = Style::model()->findAll();
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Playlists']))
		{
			if(!empty($_POST['Playlists']['styles'])) 
			{
				$stle_lst = $_POST['Playlists']['styles'];
				$style = '{'.implode(',',$_POST['Playlists']['styles']).'}';
				//else $style = '';
				$_POST['Playlists']['styles'] = $style;
			}
			$model->attributes=$_POST['Playlists'];
			$model->style = $style;
			if($model->save())
			{
				if(!empty($stle_lst))
				{ 
					//$stle_lst = $_POST['Playlists']['styles'];
					foreach( $stle_lst as $single_style)
					{
						$condition = '`playlist` = '.$model->id.' AND `style` = '.$single_style;
						$list = $percentage->findAll(array('condition'=> $condition));
						if(empty($list))
						{
							$percentage->setIsNewRecord(true);
							$percentage->id = null;
							$percentage ->playlist = $model->id;
							$percentage ->percentage = 0;
							$percentage ->style = $single_style;
							$percentage->save(); 
						}
					}
					//exit;
					$this->redirect(array('add_style_persentage','id'=>$model->id));
				}				
				$this->redirect(array('view','id'=>$model->id));
			}
		}

		$this->render('update',array(
			'model'=>$model,
			'styles' => $styles,
		));
	}
	public function actionAdd_style_persentage($id)
	{
		$percentage = new Stylepercentage();
		$error = '';
		$model=$this->loadModel($id);
		$str_remove = array('{','}');
		$playlist_style = explode(',',str_replace($str_remove,'',$model->style));
		//print_r($playlist_style);
		$condition = '`playlist` = '.$id;
		$new_list = array();
		$lists = $percentage->findAll(array('condition'=> $condition));
		foreach($lists as $list)
		{
			if(in_array($list->style,$playlist_style))
			{
				$new_list[$list->id]['style'] = $list->style;
				$new_list[$list->id]['percentage'] = $list->percentage;
			}
		}
		
		$style_list = array();
		$styles = Style::model()->findAll();
		foreach($styles as $style)
		{
			$style_list[$style->id] = $style->name;
		}
		if(isset($_POST['Playlists']))
		{
			if(!empty($_POST['Playlists']['style']))
			{
				
				$style_total = 0;
				foreach($_POST['Playlists']['style'] as $style_value)
				{
					if($style_value == '') $style_value = 0;
					if(!is_numeric($style_value))
					{
						$error = 'Please enter a number.';
						
					}
					$style_total = floatval($style_total) + floatval($style_value);
				}
				if($style_total != 100 && $error == '')
				{
					$error = 'Total of styles must be 100.';
				}
				if($error == '')
				{
					foreach($_POST['Playlists']['style'] as $key=>$style_value)
					{
						if($style_value == '') $style_value = 0;
						//echo 'Id = '.$key.'Value = '.$style_value;
						$percentage->updateByPk($key,array('percentage' => $style_value));
						
					}
					$this->redirect(array('add_style_persentage','id'=>$model->id));
				}
			}
			
		}
		//print_r($new_list);
		//exit;
		$this->render('style_percentage',array(
			'model'=>$this->loadModel($id),
			'styles' => $style_list,
			'styles_percentages' => $new_list,
			'errors' => $error,
		));
	}
	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Playlists');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin($popup = '')
	{
		$criteria=new CDbCriteria();
		$model=new Playlists('search');
		$count=$model->count($criteria);
		$pages=new CPagination($count);
		$styles = Style::model()->findAll();
		// results per page
		$pages->pageSize=10;
		$pages->applyLimit($criteria);
		$models=$model->findAll($criteria);
		$this->render('admin', array(
				'models' => $models,
				'pages' => $pages,
				'styles' => $styles,
				'popup' => $popup
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Playlists the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Playlists::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Playlists $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='playlists-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
