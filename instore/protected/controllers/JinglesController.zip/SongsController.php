<?php

class SongsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column3';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
		$this->layout = 'tag_popup';
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delet'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$styles = Style::model()->findAll();
		$this->render('view',array(
			'model'=>$this->loadModel($id),
				'styles' => $styles,
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		$model=new Songs;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
		if(isset($_POST) && !empty($_POST['Songs']))
        {
         	$file_name = $_FILES['Songs']['name']['song'];
         	if(!$model->validate())
         	{
         		$errores = $model->getErrors();
         		//print_r($errores);
         		//exit;
         		$this->render('create', array('model'=>$model));
         		exit;
         	}
        	$model->song=CUploadedFile::getInstance($model,'song');
        	$song_name = $model->song->name;
        	
        	//exit;
        	$path = Yii::getPathOfAlias('webroot')."\songs\on".date('y-m');
        	if (!file_exists($path)) {
        		mkdir(Yii::getPathOfAlias('webroot').'\songs\on'.date('y-m'), 0777);
        	}
        	$extention_array = explode('.',$song_name);
        	$extention = end($extention_array);
        	$name = time(); // rand(1000,9999) optional
        	$name = md5($name).'.'.$extention; //optional
        	if($model->save())
            {
            	$model->updateByPk($model->id,array('name' => $song_name ,'path' =>'on'.date('y-m').'/song_'.$name));
            	$model->song->saveAs($path .'\song_'. $name);
            	$this->redirect(array('update','id'=>$model->id));
            	 
                // redirect to success page
            }
        }
        $this->render('create', array('model'=>$model));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{		
		///$this->layout = 'tag_popup';
		$model=$this->loadModel($id);
		$styles = Style::model()->findAll();
		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Songs']))
		{
			if(!empty($_POST['Songs']['styles']))
				$style = '{'.implode(',',$_POST['Songs']['styles']).'}';
			else $style = '{0}';
			//echo $style;
			if($model->updateByPk($model->id,array('style'=>$style)))
				$this->redirect(array('admin','popup'=>'exit'));
		}

		$this->render('update',array(
			'model'=>$model,
			'styles' => $styles,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelet($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Songs');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin($popup = '')
	{
		
		$criteria=new CDbCriteria();
		$model=new Songs();
		$count=$model->count($criteria);
		$pages=new CPagination($count);
		$styles = Style::model()->findAll();
		// results per page
		$pages->pageSize=10;
		$pages->applyLimit($criteria);
		$models=$model->findAll($criteria);
		$this->render('admin', array(
				'models' => $models,
				'pages' => $pages,
				'styles' => $styles,
				'popup' => $popup
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Songs the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Songs::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Songs $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='songs-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
